/*
=======================================================

** Week 4 - Project 2**
*** jQuery Mania ***


=======================================================
*/

// Add your JS here.


$(document).ready(function() {  
    
    
//1. 
   
   
//2.  
    
    
//3. 
   
	    
//4.
 
   
//5. 

	
//6.
	
	
//7.

	
	
//8.



//9.



});  // Close: $(document).ready(function() { 
	
	

	
	
