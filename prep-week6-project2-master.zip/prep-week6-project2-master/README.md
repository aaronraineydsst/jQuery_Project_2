# jQuery (Project 2)

More jQuery practice.

> Reminder: Solution Guide is provided for this project.
